<?php $__env->startSection('content'); ?>

    <br><hr>
    <h1>Login</h1>
    <hr><br>

    <div class="container text-center">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <div >
                        <h3 style="background-color: red; border-radius: 10px;" class="text-center">Credenciais Erradas</h3>
                    <br>
                </div>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <fieldset>
                <legend>Email: </legend>
                <input type="text" id="email" name="email" class="users-input-text-style"><br>

            </fieldset>
            <br>
            <fieldset>
                <legend>Password: </legend>
                <input type="password" id="password" name="password" class="users-input-text-style"><br>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Password invalida
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
            <br><hr>
            <button type="submit" class="btn btn-primary">Submeter</button>
            <br><br>
            <a href="<?php echo e(route('password.request')); ?>">Esqueci-me da password</a>
        </form>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/auth/login.blade.php ENDPATH**/ ?>