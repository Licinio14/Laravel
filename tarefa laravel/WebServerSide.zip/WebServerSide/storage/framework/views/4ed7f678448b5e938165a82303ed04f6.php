<?php $__env->startSection('content'); ?>

    <br><hr><br>

    <div class="container-fluid text-center">

        <img src="<?php echo e(asset('img/perdido.avif')); ?>" alt="imagem de pessoa perdida">
        <h1>Estas perdido?</h1>
        <a href="<?php echo e(route('home')); ?>"><h3>Esperimenta clicar aqui.</h3></a>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/fallback.blade.php ENDPATH**/ ?>