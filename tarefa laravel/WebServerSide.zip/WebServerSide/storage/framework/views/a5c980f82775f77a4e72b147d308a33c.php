<?php $__env->startSection('content'); ?>

    <?php if(session('message')): ?>
        <br><hr><br>

        <div class="container-fluid message-add-user-sucess text-center">
            <h3><?php echo e(session('message')); ?></h3>
        </div>

        <br><hr><br>
    <?php endif; ?>

    <div class="container-fluid">


        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->user_type == 1): ?>

                <hr>
                <h1 class="merriweather-regular text-center">Bem-vindo administrador <?php echo e(Auth::user()->name); ?></h1>
                <hr>

            <?php else: ?>

                <hr>
                    <h1 class="merriweather-regular text-center">Bem-vindo <?php echo e(Auth::user()->name); ?></h1>
                <hr>

            <?php endif; ?>
        <?php endif; ?>

        <table class="table table-dark table-striped table-hover text-center">

            <tr>
                <td>ID</td>
                <td>Foto</td>
                <td>Nome</td>
                <td>Email</td>
                <td>Tipo</td>
                <?php if(auth()->guard()->check()): ?>
                    <td></td>
                <?php endif; ?>
            </tr>

            <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($array->id); ?></td>
                        <td><img width="50px" height="50px" src="<?php echo e($array->photo ? asset('storage/' . $array->photo ) : asset('img/noimage.png')); ?>"> </td>
                        <td><?php echo e($array->name); ?></td>
                        <td><?php echo e($array->email); ?></td>
                        <td><?php echo e($array->user_type == 1 ? "Admin" : "User"); ?></td>


                            <?php if(auth()->guard()->check()): ?>
                                <td>



                                <?php if(Auth::user()->user_type == 1): ?>
                                    <a class="btn btn-danger" href="<?php echo e(route('users.edit', $array->id)); ?>">Editar Utilizador</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('users.delete', $array->id)); ?>">Apagar</a>
                                <?php endif; ?>

                                </td>
                            <?php endif; ?>

                    </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <script>
            // Aqui estamos passando a variável PHP para o JavaScript
            var dados = <?php echo json_encode($Users, 15, 512) ?>;
        </script>

        <?php if(isset($edit)): ?>
        <script>
            window.onload = function() {
                UserShow();
            };
        </script>
        <?php endif; ?>

        <br><br>

        
        <div class="modal modal-add-gifts" id="addGifts">
            <div class="modal-content" id="formAddGifts">
                <form method="POST" action="<?php echo e(route('users.create')); ?>" class="text-center" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <h1 class="merriweather-regular">Editar Utilizador</h1>

                    <hr>
                    <fieldset>
                        <input type="hidden" id="id" name="id" value="<?php echo e(isset($edit) ? $edit->id : null); ?>" class="users-input-text-style"><br>
                    </fieldset>
                    <fieldset>
                        <legend>Nome: </legend>
                        <input type="text" id="name" name="name" value="<?php echo e(isset($edit) ? $edit->name : null); ?>" class="users-input-text-style"><br>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            Nome invalido
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                    <br>
                    <fieldset>
                        <legend>Tipo: </legend>
                        <input type="number" id="user_type" name="user_type" value="<?php echo e(isset($edit) ? $edit->user_type : null); ?>" class="users-input-text-style" step="1" min="0" max="1"><br>
                        <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            Tipo invalido
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                    <br>
                    <fieldset>
                        <legend>Imagem da banda: </legend>
                        <img id="imagemMostrar" src="<?php echo e(isset($edit) && $edit->photo != "" ? asset('storage/' . $edit->photo ) : asset('img/noimage.png')); ?>" width="50px" height="50px"><br><br>
                        <input type="file" accept="/image" id="photo" name="photo" class="users-input-text-style"><br>
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            Foto invalida
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                    <br>
                    <br><hr>
                    <button type="submit" class="btn btn-primary">Submeter</button>

                </form>
            </div>
        </div>


        <script src=<?php echo e(asset('js/scriptUsers.js')); ?>></script>


        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/dashboard/show.blade.php ENDPATH**/ ?>