<?php $__env->startSection('content'); ?>

    <?php if(session('message')): ?>
    <div class="container-fluid message-add-user-sucess text-center">
        <h3><?php echo e(session('message')); ?></h3>
    </div>
    <?php endif; ?>

    <br>

    <h1>Aqui vês todos os albuns da banda</h1>

    <br><hr><hr>


    

    <div class="container-fluid text-center">

    <form action="">
        <input type="text" id="search" name="search" value="<?php echo e(request()->query('search')); ?>">
        <button type="submit" class="btn btn-secondary">Procurar</button>
    </form>

    </div>





    <hr><hr><br>


        <table class="table table-dark table-striped table-hover text-center">

        <tr>
            <td>ID</td>
            <td>Nome</td>
            <td>Banda</td>
            <td>Data Lançamento</td>
            <td>Foto</td>
            <?php if(auth()->guard()->check()): ?>
                <td></td>
            <?php endif; ?>
        </tr>

        <?php $__currentLoopData = $BandInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($array->id); ?></td>
                    <td><?php echo e($array->name); ?></td>
                    <td><?php echo e($array->id_banda); ?></td>
                    <td><?php echo e($array->date); ?></td>
                    <td><img width="50px" height="50px" src="<?php echo e($array->photo ? asset('storage/' . $array->photo ) : asset('img/noimage.png')); ?>"> </td>

                        <?php if(auth()->guard()->check()): ?>
                            <td>

                                <a class="btn btn-danger" onclick="albunsShow(<?php echo e($array->id); ?>)" >Editar Albuns</a>

                            <?php if(Auth::user()->user_type == 1): ?>
                                <a class="btn btn-danger" href="<?php echo e(route('albuns.delete', $array->id)); ?>">Apagar</a>
                            <?php endif; ?>

                            </td>
                        <?php endif; ?>

                </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <hr>

    <div class="container-fluid">
        <?php echo e($BandInfo->links('pagination::bootstrap-5')); ?>

    </div>

    <br><hr><hr>


    <?php if(auth()->guard()->check()): ?>

        <?php if(Auth::user()->user_type == 1): ?>



            <div class="container-fluid text-center">
                <h1>Adicionar novo album</h1>
                <img src="<?php echo e(asset('img/new.png')); ?>" alt="imagem: nova prenda" class="img-gifts-add" style="cursor: pointer;" onclick="Show()">
            </div>

            <hr><hr><br>
        <?php endif; ?>


    <?php endif; ?>

<script>
    // variavel php  para js
    var dados = <?php echo json_encode($BandInfo, 15, 512) ?>;
</script>




<div class="modal modal-add-gifts" id="addGifts">
    <div class="modal-content" id="formAddGifts">
        <form method="POST" action="<?php echo e(route('albuns.create')); ?>" class="text-center" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <h1 class="merriweather-regular">Adicionar novo album</h1>

            <hr>
            <fieldset>
                <input type="hidden" id="id" name="id" value="<?php echo e(isset($edit) ? $edit->id : null); ?>" class="users-input-text-style"><br>
            </fieldset>
            <fieldset>
                <legend>Nome do album: </legend>
                <input type="text" id="name" name="name" value="<?php echo e(isset($edit) ? $edit->name : null); ?>" class="users-input-text-style"><br>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Nome invalido
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
            <br>
            <fieldset>
                <legend>Banda: </legend>
                <select id="id_banda" name="id_banda" class="users-input-text-style">
                    <?php $__currentLoopData = $bandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opcao->id); ?>"><?php echo e($opcao->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['id_banda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Banda invalida
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
            <br>
            <fieldset>
                <legend>Data de lançamento: </legend>
                <input type="date" id="date" name="date" value="<?php echo e(isset($edit) ? $edit->quant_albuns : 0); ?>" class="users-input-text-style"><br>
                <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Data invalida
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
            <br>
            <fieldset>
                <legend>Imagem do album: </legend>
                <img id="mostrarImagem" src="" width="50px" height="50px"><br><br>
                <input type="file" accept="/image" id="photo" name="photo" class="users-input-text-style"><br>
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Foto invalida
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>
            <br>
            <br><hr>
            <button type="submit" class="btn btn-primary">Submeter</button>

        </form>
    </div>
</div>


<script src=<?php echo e(asset('js/scriptAlbuns.js')); ?>></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/albuns/show_all.blade.php ENDPATH**/ ?>