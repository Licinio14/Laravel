<?php $__env->startSection('content'); ?>

    <?php if(session('message')): ?>
        <br>

        <div class="container-fluid message-add-user-sucess text-center">
            <h3><?php echo e(session('message')); ?></h3>
        </div>
    <?php endif; ?>

    <br>

    <h1 class="merriweather-regular">Aqui vês todas as bandas</h1>

    <br><hr><hr>

    

    <div class="container-fluid text-center">

    <form action="">
        <input type="text" id="search" name="search" value="<?php echo e(request()->query('search')); ?>">
        <button type="submit" class="btn btn-secondary">Procurar</button>
    </form>

    </div>





    <hr><hr><br>
    <table class="table table-dark table-striped table-hover text-center">

    <tr>
        <td>ID</td>
        <td>Nome</td>
        <td>Albuns Lançados</td>
        <td>Foto</td>
        <td></td>
    </tr>

    <?php $__currentLoopData = $BandInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($array->id); ?></td>
                <td><?php echo e($array->name); ?></td>
                <td><?php echo e($array->quant_albuns); ?></td>
                <td><img width="50px" height="50px" src="<?php echo e($array->photo ? asset('storage/' . $array->photo ) : asset('img/noimage.png')); ?>"> </td>
                <td><a class="btn btn-info" href="<?php echo e(route('bands.show_one', $array->id)); ?>">Ver Albuns</a>




                    <?php if(auth()->guard()->check()): ?>
                        <a class="btn btn-danger" href="<?php echo e(route('bands.edit', $array->id)); ?>">Editar Banda</a>

                        <?php if(Auth::user()->user_type == 1): ?>
                            <a class="btn btn-danger" href="<?php echo e(route('bands.delete', $array->id)); ?>">Apagar Banda</a>
                        <?php endif; ?>

                    <?php endif; ?>
                </td>
            </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>



    <?php if(auth()->guard()->check()): ?>

        <?php if(Auth::user()->user_type == 1): ?>

            <br><hr><hr>

            <div class="container-fluid text-center">
                <h1>Adicionar nova banda</h1>
                <img src="<?php echo e(asset('img/new.png')); ?>" alt="imagem: nova prenda" class="img-gifts-add" style="cursor: pointer;" onclick="Show()">
            </div>
            
            <hr><hr><br>
        <?php endif; ?>


    <?php endif; ?>



    <?php if(isset($edit)): ?>
        <script>
            window.onload = function() {
                ShowEditar();
            };
        </script>
    <?php endif; ?>


    
    <div class="modal modal-add-gifts" id="addGifts">
        <div class="modal-content" id="formAddGifts">
            <form method="POST" action="<?php echo e(route('bands.create')); ?>" class="text-center" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <h1 class="merriweather-regular">Adicionar nova banda</h1>

                <hr>
                <fieldset>
                    <input type="hidden" id="id" name="id" value="<?php echo e(isset($edit) ? $edit->id : null); ?>" class="users-input-text-style"><br>
                </fieldset>
                <fieldset>
                    <legend>Nome da banda: </legend>
                    <input type="text" id="name" name="name" value="<?php echo e(isset($edit) ? $edit->name : null); ?>" class="users-input-text-style"><br>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        Nome invalido
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </fieldset>
                <br>
                <fieldset>
                    <legend>Quantidade de albuns: </legend>
                    <input type="number" id="quant_albuns" name="quant_albuns" value="<?php echo e(isset($edit) ? $edit->quant_albuns : 0); ?>" class="users-input-text-style" step="1" min="0"><br>
                    <?php $__errorArgs = ['quant_albuns'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        Quantidade invalida
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </fieldset>
                <br>
                <fieldset>
                    <legend>Imagem da banda: </legend>
                    <img id="imagemMostrar" src="<?php echo e(isset($edit) && $edit->photo != "" ? asset('storage/' . $edit->photo ) : asset('img/noimage.png')); ?>" width="50px" height="50px"><br><br>
                    <input type="file" accept="/image" id="photo" name="photo" class="users-input-text-style"><br>
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        Foto invalida
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </fieldset>
                <br>
                <br><hr>
                <button type="submit" class="btn btn-primary">Submeter</button>

            </form>
        </div>
    </div>


    <script src=<?php echo e(asset('js/script.js')); ?>></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/bands/show_all.blade.php ENDPATH**/ ?>