<?php $__env->startSection('content'); ?>

    <br><hr>
    <?php if(@session('status')): ?>
        <div class="alert alert-sucess">Iremos enviar um email para recuperação da password</div>
    <?php endif; ?>

    <br><hr>
    <h1>Recuperar Pass</h1>
    <hr><br>

    <div class="container text-center">
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <div >
                        <h3 style="background-color: red; border-radius: 10px;" class="text-center">Credenciais Erradas</h3>
                    <br>
                </div>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <fieldset>
                <legend>Email: </legend>
                <input type="text" id="email" name="email" class="users-input-text-style"><br>

            </fieldset>
            <br><hr>
            <button type="submit" class="btn btn-primary">Submeter</button>
            <br><br>
        </form>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fo_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lince/Desktop/git/Laravel/tarefa laravel/WebServerSide/resources/views/auth/reset.blade.php ENDPATH**/ ?>